//
//  ContentView.swift
//  Buttons
//
//  Created by Jaime  Lujan on 10/19/19.
//  Copyright © 2019 Jaime  Lujan. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Hello World")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
