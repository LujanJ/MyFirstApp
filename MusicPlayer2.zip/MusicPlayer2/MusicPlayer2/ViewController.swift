//
//  ViewController.swift
//  MusicPlayer2
//
//  Created by Jaime  Lujan on 10/22/19.
//  Copyright © 2019 Jaime  Lujan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

